<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>insert</title>
</head>
<body>
<?php session_start();
$conn=mysqli_connect("127.0.0.1","localhost","","dhi","24000");
$conn->query('set names gb2312');
if(empty($conn))
{
   die("Connection Failed");
}
$UserName=$_POST['username'];
$pwd=$_POST['password'];
$email=$_POST['email'];
$sex=$_POST['sex'];
$time=time();
$code=strtolower($_POST["code"]);
$str="select * from users where username='".$username."'";
   $result1=$conn->query($str);
   $row=$result1->fetch_row();
if($row)
{ 
$temp="UserName already existed, please choose another one"; 
echo $temp;
echo"<a href=register.html>Return</a>";
} 
else {
   $sql="INSERT INTO users VALUES('$username', '$password','$email','$sex','$time')";
   $result=$conn->query($sql);
   if($result==true)
      {
      $_SESSION['mail']="Register Successful";
      echo "<script>window.location.href='login1.php'</script>";
      }
      else {echo "Register Failed".mysql_error();}
}
?>
</body>
</html>