<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="refresh" content="0; url=javascript:window.history.go(-1);">
<title>add</title>
</head>

<body>
<?php
// Create connection
$con=mysqli_connect("127.0.0.1","@localhost","","dhi");

// Check connection
if (mysqli_connect_errno($con)){
	echo "Failed to connect to MySQL: " . mysqli_connect_error();
 	}
// if logged in
if(!isset($_COOKIE['username']))
{
	$temp=$_COOKIE['username'];
	$sql="INSERT INTO mismatch_user(username, Like) VALUES ($temp,'2days')";
	if (!mysqli_query($con,$sql))
	  {
	  die('Error: ' . mysqli_error($con));
	  }
}
else
{
	echo 'you need to login first';
}
?>
</body>
</html>